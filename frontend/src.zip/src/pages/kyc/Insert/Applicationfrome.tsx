import React from 'react'
import { Box, TextField, Button, Grid, InputLabel, FormControl, Select, MenuItem, Paper, Typography, TextareaAutosize, Snackbar } from '@mui/material';
import Header from '../../../layouts/header/header';
function Applicationfrome() {
    return (
        <>
            <Box sx={{ display: 'flex' }}>
                <Header />
                <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
                    <div>Applicationfrome</div>
                </Box>
            </Box>
        </>

    )
}

export default Applicationfrome