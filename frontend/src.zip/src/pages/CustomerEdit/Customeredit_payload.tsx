export interface CustomerEditData {
  frmDate: string;
  toDate: string;
  name: string;
  count: string;
  userName: string;
  created_at: string;
  pepName: string;
  dob: string;
  panNum: string;
  sourceLink: string;
  pepId: number,
  uid: number,
  fatherName: string;
}