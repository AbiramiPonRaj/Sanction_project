export interface StatusPayload {
  name: string;
  code: string
};