export interface IdNumberPayload {
  id: number;
  name: string;
}