export interface QcViewData {
  frmDate: string;
  toDate: string;
  name: string;
  count: string;
}