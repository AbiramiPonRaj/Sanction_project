export interface ReassignTaskData {
  frmDate: string;
  toDate: string;
  name: string;
  count: string;
}