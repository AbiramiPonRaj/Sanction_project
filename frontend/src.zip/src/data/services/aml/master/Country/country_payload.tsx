export interface CountryPayload {
    name: string;
}
