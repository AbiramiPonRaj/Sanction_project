interface RelativeChildrenDTO {
    pepId: number;
    relativeDetId: number;
    childrenName: string;
    pan: string; // Rename 'pan' to 'childrenPan'
  }
  export default RelativeChildrenDTO;