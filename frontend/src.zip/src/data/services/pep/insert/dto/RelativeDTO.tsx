interface RelativeDTO {
    pepId: number;
    relativeMasterId: string;
    relativeName: string;
    pan: string;
  }
  export default RelativeDTO;