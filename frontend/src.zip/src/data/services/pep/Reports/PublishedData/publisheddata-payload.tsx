export interface PublishedData {
    frmDate: string;
      toDate: string;
      count: string;
  }