export interface ManagerApproveData {
    frmDate: string;
      toDate: string;
      name: string;
      count: string;
  }