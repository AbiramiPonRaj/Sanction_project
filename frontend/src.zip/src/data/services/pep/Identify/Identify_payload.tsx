export interface Identifieds {
    uid: string;
    pepId: number;
    name: string;
    pepName : string;
    identity : string;
    who : string;
    sourceLink : string;
    dob : string;
    countryId: number;
    stateId: number;
    
}
