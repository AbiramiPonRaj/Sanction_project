export interface PendingAlertPayload {
    // id: string;
    // id1:string;
    // criminalId:string;
    // name:string;
    // matchingScore:string;
    // remark:string;
    // status:string;

    id: string;
    searchId: string;
    hitId:string;
    criminalId: string;
    criminalName: string;
    matchingScore: string;
    remark: string;
    status:string;
  }