export interface HitdataPayload {
  name: string;
  display: string;
  criminalId: string;
  searchId: string;
  matchingScore: string
  statusNowId: string;
  cycleId: string;
}; 